//
//  OneBissApp.swift
//  OneBiss
//
//  Created by onetouch on 11/01/2023.
//

import SwiftUI

@main
struct OneBissApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
