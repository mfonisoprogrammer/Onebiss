//
//  OtpUIView.swift
//  OneBiss
//
//  Created by onetouch on 27/01/2023.
//

import SwiftUI

struct OtpUIView: View {
    var body: some View {
    
        
        VStack{
            Spacer()
            Spacer()
            Spacer()
            Spacer()
            Text("Enter the six(6) digit verification code sent to your phone/email address")
                .multilineTextAlignment(.center)
            .padding()
             
             
            VStack{
                TextField("", text: /*@START_MENU_TOKEN@*//*@PLACEHOLDER=Value@*/.constant("")/*@END_MENU_TOKEN@*/)
                    .padding()
                    .frame(width: 150, height:50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    .border(/*@START_MENU_TOKEN@*/Color.black/*@END_MENU_TOKEN@*/)
                    .background(Color.white.opacity(0.05))
                    .frame(width: 300, height:50, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    .cornerRadius(13.0)
                        
                VStack{
                    
                    Text("Didn’t receive it? Resend")
                    .lineSpacing(12)
                    Spacer()
                    Spacer()
                    Spacer()
                    Spacer()
                    VStack(alignment: .center){
                        Button("Confirm"){
                            
                        }
                        
                        
                        .font(.headline)
                            .foregroundColor(.white)
                            .padding()
                        .frame(width: 275, height:38, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                            .frame(width: 300, height: 50)
                            .background(Color.green)
                            .cornerRadius(15.0)
                
                   Spacer()
               }
            }
             
    }
}
    }

struct OtpUIView_Previews: PreviewProvider {
    static var previews: some View {
        OtpUIView()
    }
}


}
