//
//  Selectcategory.swift
//  OneBiss
//
//  Created by onetouch on 13/02/2023.
//

import SwiftUI
 
struct Selectcategory: View {
    var body: some View {
        VStack{
            Text("Select Category")
            .font(.callout)
            .frame(width: 125, height: 16, alignment: .topLeading)
            .lineSpacing(16)
            .padding(.vertical, 14)
            .padding(.leading, 69)
            .padding(.trailing, 70)
            .frame(width: 264, height: 44)
            .background(Color(red: 0.96, green: 0.96, blue: 0.96, opacity: 0.50))
            .cornerRadius(10)
            .frame(width: 264, height: 44)
        
        HStack{
             
            Text("Tourism/Nature")
            .font(.subheadline)
            .lineSpacing(12)
            
            Text("Interiors")
            .font(.subheadline)
            .lineSpacing(12)
            
            }
            HStack{
                Text("Education")
                .font(.subheadline)
                .lineSpacing(12)
                Text("Food/Catering")
                .font(.subheadline)
                .lineSpacing(12)
            }
        
            HStack{
                Text("Health/Fitness")
                .font(.subheadline)
                .lineSpacing(12)
                Text("Travel/Transport")
                .font(.subheadline)
                .lineSpacing(12)
                
            }
            
        
            HStack{
                Text("Engineering")
                .font(.subheadline)
                .lineSpacing(12)
                Text("Caregivers")
                .font(.subheadline)
                .lineSpacing(12)
            }
            HStack{
                Text("Entertainment")
                .font(.subheadline)
                .lineSpacing(12)
                Text("Cleaning")
                .font(.subheadline)
                .lineSpacing(12)
            }
        }
        }
    }
    


struct Selectcategory_Previews: PreviewProvider {
    static var previews: some View {
        Selectcategory()
    }
}

