//
//  SearchUIView.swift
//  OneBiss
//
//  Created by onetouch on 08/02/2023.
//

import SwiftUI

struct SearchUIView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct SearchUIView_Previews: PreviewProvider {
    static var previews: some View {
        SearchUIView()
    }
}
