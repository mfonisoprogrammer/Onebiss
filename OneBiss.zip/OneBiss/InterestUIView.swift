//
//  InterestUIView.swift
//  OneBiss
//
//  Created by onetouch on 30/01/2023.
//

import SwiftUI

struct InterestUIView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/) 
    }
}

struct InterestUIView_Previews: PreviewProvider {
    static var previews: some View {
        InterestUIView()
    }
}
